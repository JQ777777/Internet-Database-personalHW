$(document).ready(function() {
  // 创建一个iframe来承载popup.html的内容
  const searchContainer = `
    <iframe id="baidu-search-popup" src="popup.html" frameborder="0" 
            style="position: fixed; top: 10px; right: 10px; width: 250px; height: 50px; 
                   z-index: 2147483647; background-color: white; border: 1px solid #ccc;"></iframe>
  `;

  // 将搜索框添加到页面右上角
  $('body').prepend(searchContainer);

  // 监听iframe加载完成
  $('#baidu-search-popup').on('load', function() {
    const iframeDoc = this.contentDocument || this.contentWindow.document;
    // 调整iframe内部容器大小
    iframeDoc.querySelector('.search-container').style.height = '50px';
  });
});