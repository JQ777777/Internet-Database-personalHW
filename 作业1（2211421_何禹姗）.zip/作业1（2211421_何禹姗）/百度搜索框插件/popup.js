document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM fully loaded and parsed');
  
  var form = document.getElementById('baiduSearchForm');
  form.addEventListener('submit', function(event) {
    event.preventDefault(); // 阻止默认行为
    console.log('Form submitted');

    var inputElement = form.elements['wd'];
    var query = inputElement.value.trim(); // 获取输入值并修剪
    
    if (query.length > 0) { // 如果输入非空
      var searchUrl = `https://www.baidu.com/s?wd=${encodeURIComponent(query)}`; // 构建URL
      console.log('Search URL:', searchUrl); // 输出URL
      
      var newTab = window.open(searchUrl, '_blank'); // 在新标签页中打开链接
      console.log('New tab:', newTab); // 输出新标签的状态
    } else {
      console.log('No search query entered');
    }
  });
});